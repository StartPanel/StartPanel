/* Elements */
var consoleDisplay = document.getElementById("consoleDisplay");
var commandInput = document.getElementById("commandInput");
var commandSubmit = document.getElementById("commandSubmit");
/* Functions */
var getPage = function(url, callback) {
    // Feature detection
    if (!window.XMLHttpRequest) return;
    // Create new request
    var xhr = new XMLHttpRequest();
    // Setup callback
    xhr.onload = function() {
        if (callback && typeof(callback) === 'function') {
            callback(this.responseXML);
        }
    }
    // Get the HTML
    xhr.open('GET', url );
    xhr.responseType = 'document';
    xhr.send();
};

var run = setInterval(function() {
    /* Update Console */
    var consoleText = "";
    getPage("/server/rawconsole/?id=<?php echo ?>", consoleText);
    consoleDisplay.innerHTML.value = consoleText;
    /* Check Scroll */
    var isScrolledToBottom = consoleDisplay.scrollHeight - consoleDisplay.clientHeight <= consoleDisplay.scrollTop + 10;
    if (isScrolledToBottom) {
        consoleDisplay.scrollTop = consoleDisplay.scrollHeight - consoleDisplay.clientHeight;
    }
}, 250);

consoleDisplay.scrollTop = consoleDisplay.scrollHeight