        <br>
        </main>
        <footer class="footer">
            <div class="container">
                <span class="float-right">&copy; <?php echo date('Y'); ?> <a href="https://github.com/StartPanel/StartPanel">StartPanel</a></span>
            </div>
        </footer>